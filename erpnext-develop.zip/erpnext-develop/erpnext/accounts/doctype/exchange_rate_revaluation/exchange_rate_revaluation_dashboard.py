from __future__ import unicode_literals

def get_data():
	return {
		'fieldname': 'reference_name',
		'transactions': [
			{
				'items': ['Journal Entry']
			}
		]
	}
