def function_name(input):
	# ruleid: frappe-codeinjection-eval
	eval(input)

# ok: frappe-codeinjection-eval
eval("1 + 1")
